class Edge(object):
    """docstring for Edge."""
    def __init__(self, src, dst, weigth):
        super(Edge, self).__init__()
        self.src = src
        self.dst = dst
        self.weigth = weigth
